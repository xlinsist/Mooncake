#!/usr/bin/env bash
set -Eeuo pipefail

: "${RUN_ID:?set RUN_ID}"
: "${ACTION:?set ACTION}"

repo=/sharenvme/userhome/zhouxulin/mooncake-kv-e82f0bb7
run_sh="$repo/experiments/nvmeof/run.sh"
telemetry="$repo/experiments/nvmeof/telemetry.py"
master="$repo/build-nof/mooncake-store/src/mooncake_master"
bench="$repo/build-nof/mooncake-store/benchmarks/nof_worker_pool_bench"
out="/sharenvme/userhome/zhouxulin/mooncake-kv-load-results/${OUT_LABEL:-$RUN_ID-kv-load-sweep}"
source "$repo/experiments/nvmeof/config.env"

mkdir -p "$out"/{anchors,cells,harness,inventory,loads,register,service-logs,smoke,telemetry}

cell_dir() {
  printf '%s/cells/%s-trial%s\n' "$out" "$1" "$2"
}

anchor_dir() {
  printf '%s/anchors/%s-%s\n' "$out" "$1" "$2"
}

wait_for_port() {
  local port=$1 expected=$2 attempt
  for attempt in $(seq 1 80); do
    if ss -ltn | grep -q ":$port "; then
      [[ $expected == up ]] && return 0
    else
      [[ $expected == down ]] && return 0
    fi
    sleep 0.5
  done
  echo "port $port did not become $expected" >&2
  return 1
}

stop_master() {
  local pids
  pids=$(pgrep -x mooncake_master || true)
  if [[ -n $pids ]]; then
    while read -r pid; do
      [[ -z $pid ]] || sudo -n kill "$pid"
    done <<<"$pids"
  fi
  wait_for_port 50051 down
  wait_for_port 9003 down
}

start_master() {
  local policy=$1 label=$2 log="$out/service-logs/master-$2.log"
  stop_master
  nohup sudo -n env MC_HETERO_STORAGE_POLICY="$policy" \
    "$master" --rpc_address=10.0.0.34 --enable_offload=true --logtostderr=true \
    >"$log" 2>&1 </dev/null &
  echo "$!" >"$out/service-logs/master-$label.launcher-pid"
  wait_for_port 50051 up
  wait_for_port 9003 up
  local pid owner actual_policy
  pid=$(pgrep -n -x mooncake_master)
  owner=$(ps -o user= -p "$pid" | xargs)
  actual_policy=$(sudo -n sh -c "tr '\0' '\n' </proc/$pid/environ" | sed -n 's/^MC_HETERO_STORAGE_POLICY=//p')
  [[ $owner == root ]]
  [[ $actual_policy == "$policy" ]]
  printf '%s %s %s %s\n' "$(date -u +%FT%TZ)" "$pid" "$owner" "$actual_policy" \
    >>"$out/inventory/master-transitions.txt"
}

register_nof() {
  local label=$1 register_dir="$out/register/$1"
  mkdir -p "$register_dir"
  RESULT_DIR="$register_dir" "$run_sh" register \
    >"$out/service-logs/register-$label.log" 2>&1
}

generate_cell() {
  local scenario=$1 trial=$2 cell
  cell=$(cell_dir "$scenario" "$trial")
  mkdir -p "$cell"
  RESULT_DIR="$out/harness" \
  KV_WORKLOAD_RUN_ID="$RUN_ID-$scenario-trial$trial" \
  KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUESTS=24 \
  KV_WORKLOAD_BLOCKS_PER_REQUEST=4 \
  KV_WORKLOAD_BLOCK_SIZE=131072 \
  KV_WORKLOAD_REUSE_RATIO=0.5 \
  KV_WORKLOAD_CONCURRENCY=1 \
  KV_WORKLOAD_POLICY=round_robin \
  KV_WORKLOAD_SEED=42 \
    "$run_sh" kv-workload-generate >"$cell/generate.log" 2>&1
}

generate_anchor() {
  local target=$1 position=$2 cell
  cell=$(anchor_dir "$target" "$position")
  mkdir -p "$cell"
  RESULT_DIR="$out/harness" \
  KV_WORKLOAD_RUN_ID="$RUN_ID-anchor-$target-$position" \
  KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUESTS=24 \
  KV_WORKLOAD_BLOCKS_PER_REQUEST=4 \
  KV_WORKLOAD_BLOCK_SIZE=131072 \
  KV_WORKLOAD_REUSE_RATIO=0.5 \
  KV_WORKLOAD_CONCURRENCY=1 \
  KV_WORKLOAD_POLICY=round_robin \
  KV_WORKLOAD_SEED=42 \
    "$run_sh" kv-workload-generate >"$cell/generate.log" 2>&1
}

run_case() {
  local kind=$1 name1=$2 name2=$3 mode=$4 target=$5 case_id=$6 cell prefix
  if [[ $kind == cell ]]; then
    cell=$(cell_dir "$name1" "$name2")
    prefix="$name1-trial$name2"
  else
    cell=$(anchor_dir "$name1" "$name2")
    prefix="anchor-$name1-$name2"
  fi
  mkdir -p "$out/telemetry/$prefix"
  local command=(env RESULT_DIR="$out/harness" TRANSPARENT_RUN_ID="$RUN_ID" \
    KV_WORKLOAD_RUN_ID="$RUN_ID-$prefix" KV_WORKLOAD_RESULT_DIR="$cell" \
    KV_WORKLOAD_MODE="$mode" KV_WORKLOAD_TARGET="$target" \
    KV_WORKLOAD_CASE_ID="$case_id" "$run_sh" kv-workload-replay)
  python3 "$telemetry" \
    --output "$out/telemetry/$prefix/$case_id.system.json" \
    --interface "$CLIENT_NET_INTERFACE" --device "$LOCAL_NVME_DEVICE" -- \
    /usr/bin/time -v -o "$out/telemetry/$prefix/$case_id.time.txt" \
    "${command[@]}" >"$cell/$case_id.log" 2>&1
}

snapshot_case() {
  local when=$1 prefix=$2 case_id=$3 dir
  dir="$out/telemetry/$prefix"
  mkdir -p "$dir"
  date -u +%FT%TZ >"$dir/$case_id.$when.utc.txt"
  rdma statistic show >"$dir/$case_id.$when.rdma.txt"
  sudo -n nvme smart-log -o json "$LOCAL_NVME_DEVICE" \
    >"$dir/$case_id.$when.local-smart.json"
  cat /proc/diskstats >"$dir/$case_id.$when.diskstats.txt"
  cat /proc/net/dev >"$dir/$case_id.$when.netdev.txt"
  local pid policy
  pid=$(pgrep -n -x mooncake_master)
  policy=$(sudo -n sh -c "tr '\0' '\n' </proc/$pid/environ" | sed -n 's/^MC_HETERO_STORAGE_POLICY=//p')
  printf '{"pid":%s,"owner":"%s","policy":"%s"}\n' \
    "$pid" "$(ps -o user= -p "$pid" | xargs)" "$policy" \
    >"$dir/$case_id.$when.master.json"
}

load_prefix() {
  printf '%s/loads/%s-%s-trial%s\n' "$out" "$1" "$2" "$3"
}

load_unit() {
  local scenario=${2//_/-}
  printf 'mooncake-kv-load-%s-%s-%s-%s.service\n' "$RUN_ID" "$1" "$scenario" "$3"
}

start_load() {
  local phase=$1 scenario=$2 trial=$3 prefix unit
  prefix=$(load_prefix "$phase" "$scenario" "$trial")
  unit=$(load_unit "$phase" "$scenario" "$trial")
  rm -f "$prefix.exitcode" "$prefix.unit-status.txt"
  case "$scenario" in
    idle)
      printf '{"kind":"idle","requested_load":0}\n' >"$prefix.meta.json"
      ;;
    local50|local90)
      local pct=${scenario#local} calibration_iops rate_iops
      calibration_iops=$(python3 -c 'import json,sys; print(int(json.load(open(sys.argv[1]))["jobs"][0]["read"]["iops"]))' \
        "$out/calibration/local-4k-qd32.json")
      rate_iops=$((calibration_iops * pct / 100))
      python3 - "$prefix.meta.json" "$pct" "$calibration_iops" "$rate_iops" <<'PY'
import json, sys
json.dump({"kind": "local_fio", "requested_pct_of_calibration": int(sys.argv[2]),
           "calibration_iops": int(sys.argv[3]), "requested_iops": int(sys.argv[4]),
           "runtime_sec": 75, "ramp_sec": 2}, open(sys.argv[1], "w"), indent=2)
PY
      sudo -n systemd-run --unit="$unit" --property=Type=exec --property=RuntimeMaxSec=105 \
        --property="StandardOutput=append:$prefix.console.log" \
        --property="StandardError=append:$prefix.console.log" \
        fio --name="load-$phase-$scenario-trial$trial" --filename=/dev/nvme1n1 \
        --rw=randread --bs=4096 --iodepth=32 --ioengine=libaio --direct=1 \
        --time_based=1 --runtime=75 --ramp_time=2 --rate_iops="$rate_iops" \
        --size=68719476736 --group_reporting=1 --output-format=json+ \
        --output="$prefix.fio.json" >"$prefix.systemd-run.txt"
      ;;
    remote_stress)
      printf '{"kind":"remote_nof","offered_point":"1MiB/QD32","runtime_sec":75,"ramp_sec":2}\n' \
        >"$prefix.meta.json"
      sudo -n systemd-run --unit="$unit" --property=Type=exec --property=RuntimeMaxSec=105 \
        --property="StandardOutput=append:$prefix.nof.log" \
        --property="StandardError=append:$prefix.nof.log" \
        "$bench" --endpoints="traddr:10.0.0.5 trsvcid:4420 subnqn:nqn.2026-08.local.mooncake:nof-phase1 trtype:RDMA adrfam:IPv4 ns:1" \
        --rw=randread --bs=1048576 --iodepth=32 --runtime=75 --ramp_time=2 \
        --size=68719476736 --io_timeout_sec=30 --nof_workers=4 \
        --nof_submit_chunk_bytes=131072 --nof_inflight_bytes_limit=33554432 \
        >"$prefix.systemd-run.txt"
      ;;
    *) echo "unknown scenario: $scenario" >&2; return 2 ;;
  esac
  if [[ $scenario != idle ]]; then
    sleep 3
    [[ $(sudo -n systemctl is-active "$unit") == active ]]
  fi
}

check_load() {
  local phase=$1 scenario=$2 trial=$3 marker=$4 prefix unit
  prefix=$(load_prefix "$phase" "$scenario" "$trial")
  if [[ $scenario == idle ]]; then
    printf '%s idle\n' "$(date -u +%FT%TZ)" >"$prefix.$marker.liveness.txt"
  else
    unit=$(load_unit "$phase" "$scenario" "$trial")
    [[ $(sudo -n systemctl is-active "$unit") == active ]]
    printf '%s active unit=%s\n' "$(date -u +%FT%TZ)" "$unit" \
      >"$prefix.$marker.liveness.txt"
  fi
}

finish_load() {
  local phase=$1 scenario=$2 trial=$3 prefix unit attempt
  prefix=$(load_prefix "$phase" "$scenario" "$trial")
  [[ $scenario != idle ]] || return 0
  unit=$(load_unit "$phase" "$scenario" "$trial")
  for attempt in $(seq 1 110); do
    [[ $(sudo -n systemctl is-active "$unit" 2>/dev/null || true) == active ]] || break
    sleep 1
  done
  sudo -n systemctl show "$unit" -p ActiveState -p SubState -p Result -p ExecMainStatus \
    >"$prefix.unit-status.txt"
  grep -Fxq 'ActiveState=inactive' "$prefix.unit-status.txt"
  grep -Fxq 'Result=success' "$prefix.unit-status.txt"
  grep -Fxq 'ExecMainStatus=0' "$prefix.unit-status.txt"
  case "$scenario" in
    local50|local90)
      python3 - "$prefix.meta.json" "$prefix.fio.json" "$prefix.achieved.json" <<'PY'
import json, sys
meta = json.load(open(sys.argv[1])); fio = json.load(open(sys.argv[2]))
achieved = float(fio["jobs"][0]["read"]["iops"]); requested = meta["requested_iops"]
ratio = achieved / requested
result = {**meta, "achieved_iops": achieved, "achieved_to_requested_ratio": ratio}
json.dump(result, open(sys.argv[3], "w"), indent=2)
if not 0.85 <= ratio <= 1.10: raise SystemExit(f"fio achieved/requested ratio outside gate: {ratio}")
PY
      ;;
    remote_stress)
      python3 - "$prefix.nof.log" "$prefix.achieved.json" <<'PY'
import json, re, sys
text = open(sys.argv[1]).read()
def value(name):
    matches = re.findall(rf"^{re.escape(name)}=([0-9.]+)(?:\s|$)", text, re.MULTILINE)
    if not matches: raise SystemExit(f"missing {name}")
    return float(matches[-1])
result = {"bw_GiBps": value("bw"), "iops": value("iops"),
          "completed_ops": int(value("completed_ops")), "failed_ops": int(value("failed_ops")),
          "interval_lines": len(re.findall(r"interval", text, re.I))}
json.dump(result, open(sys.argv[2], "w"), indent=2)
if result["completed_ops"] <= 0 or result["failed_ops"] != 0 or result["iops"] <= 0: raise SystemExit("invalid NoF load result")
PY
      ;;
  esac
  printf '%s terminated-cleanly unit=%s\n' "$(date -u +%FT%TZ)" "$unit" \
    >"$prefix.termination.txt"
  sudo -n systemctl reset-failed "$unit" 2>/dev/null || true
}

abort_load() {
  local phase=$1 scenario=$2 trial=$3 prefix unit
  [[ $scenario != idle ]] || return 0
  prefix=$(load_prefix "$phase" "$scenario" "$trial")
  unit=$(load_unit "$phase" "$scenario" "$trial")
  sudo -n systemctl stop "$unit" 2>/dev/null || true
  printf '%s aborted unit=%s\n' "$(date -u +%FT%TZ)" "$unit" >"$prefix.abort.txt"
}

check_master_log() {
  local label=$1 log="$out/service-logs/master-$1.log"
  [[ -f $log ]]
  if grep -E 'nof_heartbeat_failure|unmount_nof_segment_by_heartbeat' "$log"; then
    echo "Master heartbeat/unmount failure in $label" >&2
    return 1
  fi
  printf '%s heartbeat-clean\n' "$(date -u +%FT%TZ)" >"$out/service-logs/master-$label.check.txt"
}

summarize_cell() {
  local scenario=$1 trial=$2 cell
  cell=$(cell_dir "$scenario" "$trial")
  RESULT_DIR="$out/harness" KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUIRED_CASES=no_store,direct-local,transparent-local,direct-remote,transparent-remote \
    "$run_sh" kv-workload-summarize >"$cell/summarize.log" 2>&1
}

summarize_anchor() {
  local target=$1 position=$2 cell required
  cell=$(anchor_dir "$target" "$position")
  required="direct-${target%%_*},transparent-${target%%_*}"
  RESULT_DIR="$out/harness" KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUIRED_CASES="$required" \
    "$run_sh" kv-workload-summarize >"$cell/summarize.log" 2>&1
}

summarize_pair() {
  local scenario=$1 trial=$2 target=$3 cell required
  cell=$(cell_dir "$scenario" "$trial")
  required="direct-${target%%_*},transparent-${target%%_*}"
  RESULT_DIR="$out/harness" KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUIRED_CASES="$required" \
    "$run_sh" kv-workload-summarize >"$cell/summarize.log" 2>&1
}

preflight() {
  date -u +%FT%TZ >"$out/inventory/started-utc.txt"
  hostname >"$out/inventory/hostname.txt"
  git -C "$repo" rev-parse HEAD >"$out/inventory/source-commit.txt"
  git -C "$repo" status --short >"$out/inventory/source-status.txt"
  sha256sum "$master" "$repo"/build-nof/mooncake-integration/mooncake/store*.so \
    >"$out/inventory/build-sha256.txt"
  ps -eo user,pid,ppid,args | grep '[m]ooncake_master' >"$out/inventory/initial-master.txt"
  ss -ltn | grep -E ':(50051|9003|8080) ' >>"$out/inventory/initial-master.txt"
  local pid owner policy serial mount_source mount_target
  pid=$(pgrep -n -x mooncake_master)
  owner=$(ps -o user= -p "$pid" | xargs)
  policy=$(sudo -n sh -c "tr '\0' '\n' </proc/$pid/environ" | sed -n 's/^MC_HETERO_STORAGE_POLICY=//p')
  [[ $owner == root ]]
  [[ $policy == round_robin ]]
  printf '%s\n' "$policy" >"$out/inventory/original-master-policy.txt"
  serial=$(sudo -n nvme id-ctrl "$LOCAL_NVME_DEVICE" | awk -F: '/^sn[[:space:]]*:/ {gsub(/^[[:space:]]+|[[:space:]]+$/, "", $2); print $2}')
  [[ $serial == "$LOCAL_NVME_SERIAL" ]]
  read -r mount_source mount_target _ < <(findmnt -no SOURCE,TARGET,FSTYPE -T "$SSD_OFFLOAD_PATH")
  [[ $mount_source == /dev/nvme1n1 ]]
  [[ $mount_target == /mnt/datassd ]]
  printf 'serial=%s\nmount_source=%s\nmount_target=%s\noffload_path=%s\n' \
    "$serial" "$mount_source" "$mount_target" "$SSD_OFFLOAD_PATH" \
    >"$out/inventory/local-load-safety.txt"
  sudo -n nvme smart-log -o json "$LOCAL_NVME_DEVICE" >"$out/inventory/local-smart-before.json"
  python3 - "$out/inventory/local-smart-before.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
temperature = float(data.get("temperature", data.get("temperature_celsius", 0)))
if temperature > 200: temperature -= 273.15
if int(data.get("critical_warning", 0)) or int(data.get("media_errors", 0)) or temperature >= 70:
    raise SystemExit(f"unsafe local SMART: temperature={temperature}, data={data}")
PY
  rdma statistic show >"$out/inventory/rdma-before.txt"
  nvme list-subsys >"$out/inventory/client-nvme-subsystems.txt"
}

policy_smoke() {
  local policy=$1 target=$2 dir="$out/smoke/$1"
  mkdir -p "$dir"
  RESULT_DIR="$dir" TRANSPARENT_RUN_ID="$RUN_ID-$policy-smoke" \
    "$run_sh" "transparent-${target%%_*}" >"$dir/run.log" 2>&1
}

recovery_smoke() {
  local dir="$out/smoke/final-round-robin"
  mkdir -p "$dir"
  RESULT_DIR="$dir" TRANSPARENT_RUN_ID="$RUN_ID-final-recovery" \
    "$run_sh" transparent-round-robin >"$dir/run.log" 2>&1
}

sacrificial_remote_load() {
  local trial=$1 prefix="$out/loads/sacrificial-trial$1"
  sudo -n "$bench" \
    --endpoints="traddr:10.0.0.5 trsvcid:4420 subnqn:nqn.2026-08.local.mooncake:nof-phase1 trtype:RDMA adrfam:IPv4 ns:1" \
    --rw=randread --bs=1048576 --iodepth=32 --runtime=2 --ramp_time=0 \
    --size=68719476736 --io_timeout_sec=30 --nof_workers=4 \
    --nof_submit_chunk_bytes=131072 --nof_inflight_bytes_limit=33554432 \
    >"$prefix.nof.log" 2>&1
  python3 - "$prefix.nof.log" "$prefix.summary.json" <<'PY'
import json, re, sys
text = open(sys.argv[1]).read()
def value(name):
    matches = re.findall(rf"^{re.escape(name)}=([0-9.]+)(?:\s|$)", text, re.MULTILINE)
    if not matches: raise SystemExit(f"missing {name}")
    return float(matches[-1])
result = {"iops": value("iops"), "completed_ops": int(value("completed_ops")),
          "failed_ops": int(value("failed_ops")), "purpose": "sacrificial_attach"}
json.dump(result, open(sys.argv[2], "w"), indent=2)
if result["completed_ops"] <= 0 or result["failed_ops"] != 0: raise SystemExit("invalid sacrificial attach")
PY
}

final_inventory() {
  ps -eo user,pid,ppid,args | grep '[m]ooncake_master' >"$out/inventory/final-master.txt"
  ss -ltn | grep -E ':(50051|9003|8080) ' >>"$out/inventory/final-master.txt"
  sudo -n nvme smart-log -o json "$LOCAL_NVME_DEVICE" >"$out/inventory/local-smart-after.json"
  python3 - "$out/inventory/local-smart-after.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
temperature = float(data.get("temperature", data.get("temperature_celsius", 0)))
if temperature > 200: temperature -= 273.15
if int(data.get("critical_warning", 0)) or int(data.get("media_errors", 0)) or temperature >= 70:
    raise SystemExit(f"unsafe local SMART: temperature={temperature}, data={data}")
PY
  rdma statistic show >"$out/inventory/rdma-after.txt"
  date -u +%FT%TZ >"$out/inventory/completed-utc.txt"
}

case "$ACTION" in
  preflight) preflight ;;
  generate-cell) generate_cell "$SCENARIO" "$TRIAL" ;;
  generate-anchor) generate_anchor "$TARGET" "$POSITION" ;;
  start-master) start_master "$POLICY" "$LABEL" ;;
  register) register_nof "$LABEL" ;;
  policy-smoke) policy_smoke "$POLICY" "$TARGET" ;;
  run-case) run_case "$KIND" "$NAME1" "$NAME2" "$MODE" "$TARGET" "$CASE_ID" ;;
  snapshot-case) snapshot_case "$WHEN" "$PREFIX" "$CASE_ID" ;;
  start-load) start_load "$PHASE" "$SCENARIO" "$TRIAL" ;;
  check-load) check_load "$PHASE" "$SCENARIO" "$TRIAL" "$MARKER" ;;
  finish-load) finish_load "$PHASE" "$SCENARIO" "$TRIAL" ;;
  abort-load) abort_load "$PHASE" "$SCENARIO" "$TRIAL" ;;
  check-master-log) check_master_log "$LABEL" ;;
  summarize-cell) summarize_cell "$SCENARIO" "$TRIAL" ;;
  summarize-anchor) summarize_anchor "$TARGET" "$POSITION" ;;
  summarize-pair) summarize_pair "$SCENARIO" "$TRIAL" "$TARGET" ;;
  recovery-smoke) recovery_smoke ;;
  sacrificial-remote-load) sacrificial_remote_load "$TRIAL" ;;
  final-inventory) final_inventory ;;
  *) echo "unknown ACTION=$ACTION" >&2; exit 2 ;;
esac
