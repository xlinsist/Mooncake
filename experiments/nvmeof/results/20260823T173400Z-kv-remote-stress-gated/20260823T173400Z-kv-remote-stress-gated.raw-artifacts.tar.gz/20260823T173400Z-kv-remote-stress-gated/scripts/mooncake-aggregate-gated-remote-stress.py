#!/usr/bin/env python3
import csv
import json
import statistics
import sys
from pathlib import Path


root = Path(sys.argv[1])
reference_iops = 6976.25
failures = []
matrix_rows = []
operation_rows = []
load_rows = []
anchor_rows = []


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def percentile(values, percent):
    ordered = sorted(values)
    return ordered[max(0, (percent * len(ordered) + 99) // 100 - 1)]


for trial in range(1, 5):
    cell = root / "cells" / f"remote_stress_gated-trial{trial}"
    conclusion = json.loads((cell / "conclusion.json").read_text())
    manifest = json.loads((cell / "manifest.json").read_text())
    if conclusion.get("status") != "pass" or set(conclusion.get("completed_cases", [])) != {"direct-remote", "transparent-remote"}:
        failures.append(f"trial {trial}: foreground conclusion")
    rows = read_csv(cell / "summary.csv")
    if len(rows) != 2:
        failures.append(f"trial {trial}: summary rows={len(rows)}")
    for row in rows:
        if int(row["operations"]) != 148 or int(row["miss"]) != 0 or int(row["remote"]) != 148 or int(row["local"]) != 0:
            failures.append(f"trial {trial}/{row['case_id']}: foreground invariants")
        matrix_rows.append({"trial": trial, "trace_sha256": manifest["trace_sha256"], **row})
    groups = {}
    for row in read_csv(cell / "operations.csv"):
        key = (row["case_id"], row["mode"], row["store_operation"])
        groups.setdefault(key, []).append(float(row["latency_us"]))
    for (case_id, mode, operation), values in sorted(groups.items()):
        operation_rows.append({"trial": trial, "case_id": case_id, "mode": mode, "operation": operation, "count": len(values), "p50_us": round(percentile(values, 50), 6), "p95_us": round(percentile(values, 95), 6), "p99_us": round(percentile(values, 99), 6)})
    measured = json.loads((root / "loads" / f"remote-gated-{trial}-remote_stress-trial{trial}.achieved.json").read_text())
    sacrificial = json.loads((root / "loads" / f"sacrificial-trial{trial}.summary.json").read_text())
    ratio = float(measured["iops"]) / reference_iops
    if not 0.80 <= ratio <= 1.20 or measured["failed_ops"] != 0:
        failures.append(f"trial {trial}: measured load invalid {measured}")
    load_rows.append({"trial": trial, "sacrificial_iops": sacrificial["iops"], "sacrificial_completed_ops": sacrificial["completed_ops"], "measured_iops": measured["iops"], "measured_bw_GiBps": measured["bw_GiBps"], "measured_completed_ops": measured["completed_ops"], "measured_failed_ops": measured["failed_ops"], "measured_to_reference_ratio": ratio})

for position in ("pre", "post"):
    directory = root / "anchors" / f"remote_nof-{position}"
    conclusion = json.loads((directory / "conclusion.json").read_text())
    if conclusion.get("status") != "pass": failures.append(f"anchor {position}: conclusion")
    for row in read_csv(directory / "summary.csv"):
        anchor_rows.append({"position": position, **row})

telemetry_files = list((root / "telemetry").glob("*/*.system.json"))
if len(telemetry_files) != 12:
    failures.append(f"telemetry files={len(telemetry_files)}")
for path in telemetry_files:
    if json.loads(path.read_text()).get("exit_code") != 0:
        failures.append(f"telemetry failure: {path}")

paired_rows = []
metrics = ("p50_latency_us", "p95_latency_us", "request_p50_latency_us", "request_p95_latency_us", "storage_wait_us", "operation_rate")
for metric in metrics:
    direct = [float(next(r for r in matrix_rows if int(r["trial"]) == trial and r["mode"] == "direct")[metric]) for trial in range(1, 5)]
    transparent = [float(next(r for r in matrix_rows if int(r["trial"]) == trial and r["mode"] == "transparent")[metric]) for trial in range(1, 5)]
    deltas = [(t / d - 1) * 100 for d, t in zip(direct, transparent)]
    paired_rows.append({"metric": metric, "direct_median": round(statistics.median(direct), 6), "transparent_median": round(statistics.median(transparent), 6), "median_paired_delta_pct": round(statistics.median(deltas), 6), "min_paired_delta_pct": round(min(deltas), 6), "max_paired_delta_pct": round(max(deltas), 6)})
for operation in ("put", "get", "remove"):
    for statistic in ("p50_us", "p95_us", "p99_us"):
        direct = [float(next(r for r in operation_rows if int(r["trial"]) == trial and r["mode"] == "direct" and r["operation"] == operation)[statistic]) for trial in range(1, 5)]
        transparent = [float(next(r for r in operation_rows if int(r["trial"]) == trial and r["mode"] == "transparent" and r["operation"] == operation)[statistic]) for trial in range(1, 5)]
        deltas = [(t / d - 1) * 100 for d, t in zip(direct, transparent)]
        paired_rows.append({"metric": f"{operation}_{statistic}", "direct_median": round(statistics.median(direct), 6), "transparent_median": round(statistics.median(transparent), 6), "median_paired_delta_pct": round(statistics.median(deltas), 6), "min_paired_delta_pct": round(min(deltas), 6), "max_paired_delta_pct": round(max(deltas), 6)})

anchor_drift = []
for mode in ("direct", "transparent"):
    for metric in ("p50_latency_us", "p95_latency_us", "request_p50_latency_us", "request_p95_latency_us"):
        values = {r["position"]: float(r[metric]) for r in anchor_rows if r["mode"] == mode}
        anchor_drift.append({"mode": mode, "metric": metric, "pre": values["pre"], "post": values["post"], "drift_pct": round((values["post"] / values["pre"] - 1) * 100, 6)})

for name, rows in (("matrix-summary.csv", matrix_rows), ("operation-summary.csv", operation_rows), ("load-summary.csv", load_rows), ("paired-overhead-summary.csv", paired_rows), ("anchor-summary.csv", anchor_rows), ("anchor-drift-summary.csv", anchor_drift)):
    with (root / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader(); writer.writerows(rows)

for label in ("gated-remote-phase", "gated-final-round-robin"):
    text = (root / "service-logs" / f"master-{label}.log").read_text(errors="replace")
    if "nof_heartbeat_failure" in text or "unmount_nof_segment_by_heartbeat" in text:
        failures.append(f"master {label}: heartbeat/unmount")
recovery = json.loads((root / "smoke" / "final-round-robin" / "transparent-round-robin.json").read_text())
if recovery.get("status") != "pass" or recovery.get("target_counts") != {"local_nvme": 6, "remote_nof": 6}:
    failures.append("recovery smoke")

conclusion = {"status": "pass" if not failures else "inconclusive", "case_rows": len(matrix_rows), "anchor_case_rows": len(anchor_rows), "telemetry_case_rows": len(telemetry_files), "load_epochs": len(load_rows), "reference_iops": reference_iops, "sacrificial_collapses": sum(row["sacrificial_iops"] < reference_iops * 0.8 for row in load_rows), "measured_iops_range": [min(row["measured_iops"] for row in load_rows), max(row["measured_iops"] for row in load_rows)], "trace_digests": sorted({row["trace_sha256"] for row in matrix_rows}), "failures": failures}
(root / "matrix-conclusion.json").write_text(json.dumps(conclusion, indent=2, sort_keys=True) + "\n")
print(json.dumps(conclusion, sort_keys=True))
raise SystemExit(0 if not failures else 1)
