#!/usr/bin/env bash
set -Eeuo pipefail

: "${RUN_ID:?set RUN_ID}"
label="$RUN_ID-kv-remote-stress-gated"
client=intel-bigmem-2
target=intel-bigmem
helper=/tmp/mooncake-load-client-helper.sh
remote_out="/sharenvme/userhome/zhouxulin/mooncake-kv-load-results/$label"
target_rpc=/sharenvme/userhome/zhouxl/mooncake-nof-phase1/spdk/scripts/rpc.py
restore_needed=1
active_phase=
active_trial=

client_action() {
  local action=$1
  shift
  ssh -o BatchMode=yes "$client" env RUN_ID="$RUN_ID" OUT_LABEL="$label" ACTION="$action" "$@" bash "$helper"
}

target_preflight() {
  ssh -o BatchMode=yes "$target" sudo -n systemctl show mooncake-nof-spdk.service -p MainPID -p ActiveState -p SubState \
    >"/tmp/$label-target-service.txt"
  ssh -o BatchMode=yes "$target" sudo -n "$target_rpc" nvmf_get_subsystems \
    >"/tmp/$label-subsystems.json"
  ssh -o BatchMode=yes "$target" sudo -n "$target_rpc" bdev_get_bdevs \
    >"/tmp/$label-bdevs.json"
  python3 - "/tmp/$label-subsystems.json" "/tmp/$label-bdevs.json" <<'PY'
import json, sys
subs = json.load(open(sys.argv[1])); bdevs = json.load(open(sys.argv[2]))
assert any(s.get("nqn") == "nqn.2026-08.local.mooncake:nof-phase1" and "1" in {str(n.get("nsid")) for n in s.get("namespaces", [])} and any(x.get("traddr") == "10.0.0.5" and str(x.get("trsvcid")) == "4420" and x.get("trtype", "").upper() == "RDMA" for x in s.get("listen_addresses", [])) for s in subs)
assert any(c.get("ctrlr_data", {}).get("serial_number", "").strip() == "PHAL13400005400AGN" for b in bdevs for c in b.get("driver_specific", {}).get("nvme", []))
PY
  scp -q "/tmp/$label-target-service.txt" "/tmp/$label-subsystems.json" "/tmp/$label-bdevs.json" "$client:$remote_out/inventory/"
}

target_snapshot() {
  local when=$1 prefix=$2 case_id=$3 destination
  destination="$remote_out/telemetry/$prefix"
  ssh -o BatchMode=yes "$target" bash -s -- "$target_rpc" "$case_id.$when.spdk-iostat.json" "$case_id.$when.target-smart.json" <<'EOF' |
set -Eeuo pipefail
rpc=$1
spdk_name=$2
smart_name=$3
snapshot_dir=$(mktemp -d)
trap 'rm -rf "$snapshot_dir"' EXIT
sudo -n "$rpc" bdev_get_iostat >"$snapshot_dir/$spdk_name"
sudo -n "$rpc" bdev_nvme_get_controller_health_info -c Nvme0 >"$snapshot_dir/$smart_name"
tar -C "$snapshot_dir" -cf - "$spdk_name" "$smart_name"
EOF
    ssh -o BatchMode=yes "$client" tar --warning=no-timestamp -C "$destination" -xf -
}

snapshot() {
  local when=$1 prefix=$2 case_id=$3
  client_action snapshot-case WHEN="$when" PREFIX="$prefix" CASE_ID="$case_id"
  target_snapshot "$when" "$prefix" "$case_id"
}

run_case() {
  local kind=$1 name1=$2 name2=$3 mode=$4 case_id="$4-remote" prefix
  if [[ $kind == cell ]]; then prefix="$name1-trial$name2"; else prefix="anchor-$name1-$name2"; fi
  snapshot before "$prefix" "$case_id"
  client_action run-case KIND="$kind" NAME1="$name1" NAME2="$name2" MODE="$mode" TARGET=remote_nof CASE_ID="$case_id"
  snapshot after "$prefix" "$case_id"
}

run_pair() {
  local kind=$1 name1=$2 name2=$3 order=$4 phase=$5 trial=$6 load_scenario=$7 first second
  if [[ $order == DT ]]; then first=direct; second=transparent; else first=transparent; second=direct; fi
  client_action check-load PHASE="$phase" SCENARIO="$load_scenario" TRIAL="$trial" MARKER="before-$first-remote"
  run_case "$kind" "$name1" "$name2" "$first"
  client_action check-load PHASE="$phase" SCENARIO="$load_scenario" TRIAL="$trial" MARKER="between-$first-$second-remote"
  run_case "$kind" "$name1" "$name2" "$second"
  client_action check-load PHASE="$phase" SCENARIO="$load_scenario" TRIAL="$trial" MARKER="after-$second-remote"
}

run_idle_anchor() {
  local position=$1 order=$2 trial
  trial="anchor-$position"
  client_action start-load PHASE=remote-gated SCENARIO=idle TRIAL="$trial"
  run_pair anchor remote_nof "$position" "$order" remote-gated "$trial" idle
  client_action finish-load PHASE=remote-gated SCENARIO=idle TRIAL="$trial"
  client_action summarize-anchor TARGET=remote_nof POSITION="$position"
}

restore() {
  set +e
  client_action start-master POLICY=round_robin LABEL=gated-final-round-robin
  client_action register LABEL=gated-final-round-robin
  client_action recovery-smoke
  local rc=$?
  set -e
  return "$rc"
}

on_exit() {
  local rc=$?
  trap - EXIT
  if [[ -n $active_phase ]]; then client_action abort-load PHASE="$active_phase" SCENARIO=remote_stress TRIAL="$active_trial" || true; fi
  if (( restore_needed )); then restore || true; fi
  exit "$rc"
}
trap on_exit EXIT

scp -q /tmp/mooncake-load-client-helper.sh "$client:$helper"
client_action preflight
target_preflight
client_action start-master POLICY=remote_only LABEL=gated-remote-phase
client_action register LABEL=gated-remote-phase
client_action policy-smoke POLICY=remote_only TARGET=remote_nof
for position in pre post; do client_action generate-anchor TARGET=remote_nof POSITION="$position"; done
run_idle_anchor pre DT

for trial in 1 2 3 4; do
  client_action generate-cell SCENARIO=remote_stress_gated TRIAL="$trial"
  sleep 10
  client_action sacrificial-remote-load TRIAL="$trial"
  phase="remote-gated-$trial"
  client_action start-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial"
  active_phase=$phase active_trial=$trial
  if [[ $trial == 1 || $trial == 3 ]]; then order=DT; else order=TD; fi
  run_pair cell remote_stress_gated "$trial" "$order" "$phase" "$trial" remote_stress
  client_action finish-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial"
  active_phase= active_trial=
  client_action summarize-pair SCENARIO=remote_stress_gated TRIAL="$trial" TARGET=remote_nof
done

run_idle_anchor post TD
client_action check-master-log LABEL=gated-remote-phase
restore
restore_needed=0
client_action final-inventory
target_preflight
