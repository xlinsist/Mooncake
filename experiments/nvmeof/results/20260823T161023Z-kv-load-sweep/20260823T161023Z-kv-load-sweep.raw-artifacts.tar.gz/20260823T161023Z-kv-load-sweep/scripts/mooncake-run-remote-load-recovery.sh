#!/usr/bin/env bash
set -Eeuo pipefail

: "${RUN_ID:?set RUN_ID}"
client=intel-bigmem-2
target=intel-bigmem
remote_helper=/tmp/mooncake-load-client-helper.sh
remote_out="/sharenvme/userhome/zhouxulin/mooncake-kv-load-results/$RUN_ID-kv-load-sweep"
target_rpc=/sharenvme/userhome/zhouxl/mooncake-nof-phase1/spdk/scripts/rpc.py
restore_needed=1
active_phase=
active_trial=

client_action() {
  local action=$1
  shift
  ssh -o BatchMode=yes "$client" env RUN_ID="$RUN_ID" ACTION="$action" "$@" bash "$remote_helper"
}

target_snapshot() {
  local when=$1 prefix=$2 case_id=$3 destination
  destination="$remote_out/telemetry/$prefix"
  ssh -o BatchMode=yes "$target" bash -s -- "$target_rpc" "$case_id.$when.spdk-iostat.json" "$case_id.$when.target-smart.json" <<'EOF' |
set -Eeuo pipefail
rpc=$1
spdk_name=$2
smart_name=$3
snapshot_dir=$(mktemp -d)
trap 'rm -rf "$snapshot_dir"' EXIT
sudo -n "$rpc" bdev_get_iostat >"$snapshot_dir/$spdk_name"
sudo -n "$rpc" bdev_nvme_get_controller_health_info -c Nvme0 >"$snapshot_dir/$smart_name"
tar -C "$snapshot_dir" -cf - "$spdk_name" "$smart_name"
EOF
    ssh -o BatchMode=yes "$client" tar --warning=no-timestamp -C "$destination" -xf -
}

snapshot() {
  local when=$1 prefix=$2 case_id=$3
  client_action snapshot-case WHEN="$when" PREFIX="$prefix" CASE_ID="$case_id"
  target_snapshot "$when" "$prefix" "$case_id"
}

run_case() {
  local trial=$1 mode=$2 case_id="$2-remote" prefix="remote_stress_recovery-trial$1"
  snapshot before "$prefix" "$case_id"
  client_action run-case KIND=cell NAME1=remote_stress_recovery NAME2="$trial" MODE="$mode" TARGET=remote_nof CASE_ID="$case_id"
  snapshot after "$prefix" "$case_id"
}

restore() {
  set +e
  client_action start-master POLICY=round_robin LABEL=remote-recovery-final
  client_action register LABEL=remote-recovery-final
  client_action recovery-smoke
  local rc=$?
  set -e
  return "$rc"
}

on_exit() {
  local rc=$?
  trap - EXIT
  if [[ -n $active_phase ]]; then
    client_action abort-load PHASE="$active_phase" SCENARIO=remote_stress TRIAL="$active_trial" || true
  fi
  if (( restore_needed )); then restore || true; fi
  exit "$rc"
}
trap on_exit EXIT

client_action start-master POLICY=remote_only LABEL=remote-recovery
client_action register LABEL=remote-recovery
client_action policy-smoke POLICY=remote_only TARGET=remote_nof

for trial in 2 4; do
  client_action generate-cell SCENARIO=remote_stress_recovery TRIAL="$trial"
  sleep 15
  phase="remote-recovery-$trial"
  client_action start-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial"
  active_phase=$phase active_trial=$trial
  client_action check-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial" MARKER=before-transparent-remote
  run_case "$trial" transparent
  client_action check-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial" MARKER=between-transparent-direct-remote
  run_case "$trial" direct
  client_action check-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial" MARKER=after-direct-remote
  client_action finish-load PHASE="$phase" SCENARIO=remote_stress TRIAL="$trial"
  active_phase= active_trial=
  client_action summarize-pair SCENARIO=remote_stress_recovery TRIAL="$trial" TARGET=remote_nof
done

client_action check-master-log LABEL=remote-recovery
restore
restore_needed=0
