#!/usr/bin/env bash
set -Eeuo pipefail

: "${RUN_ID:?set RUN_ID}"
client=intel-bigmem-2
target=intel-bigmem
helper=/tmp/mooncake-load-client-helper.sh
remote_helper=/tmp/mooncake-load-client-helper.sh
remote_out="/sharenvme/userhome/zhouxulin/mooncake-kv-load-results/$RUN_ID-kv-load-sweep"
target_rpc=/sharenvme/userhome/zhouxl/mooncake-nof-phase1/spdk/scripts/rpc.py
local_log=/tmp/mooncake-load-controller-$RUN_ID.log
restore_needed=1
active_phase=
active_scenario=
active_trial=

exec > >(tee -a "$local_log") 2>&1

client_action() {
  local action=$1
  shift
  ssh -o BatchMode=yes "$client" env RUN_ID="$RUN_ID" ACTION="$action" "$@" bash "$remote_helper"
}

target_cmd() {
  ssh -o BatchMode=yes "$target" "$@"
}

target_preflight() {
  target_cmd sudo -n systemctl is-active --quiet mooncake-nof-spdk.service
  target_cmd sudo -n systemctl show mooncake-nof-spdk.service -p MainPID -p ActiveState -p SubState \
    >"/tmp/mooncake-target-service-$RUN_ID.txt"
  target_cmd sudo -n "$target_rpc" nvmf_get_subsystems >"/tmp/mooncake-target-subsystems-$RUN_ID.json"
  python3 - "/tmp/mooncake-target-subsystems-$RUN_ID.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
for subsystem in data:
    if subsystem.get("nqn") != "nqn.2026-08.local.mooncake:nof-phase1":
        continue
    namespaces = {str(item.get("nsid")) for item in subsystem.get("namespaces", [])}
    listeners = subsystem.get("listen_addresses", [])
    if "1" in namespaces and any(item.get("traddr") == "10.0.0.5" and str(item.get("trsvcid")) == "4420" and item.get("trtype", "").upper() == "RDMA" for item in listeners):
        raise SystemExit(0)
raise SystemExit("exact NQN/NSID/listener not found")
PY
  target_cmd sudo -n "$target_rpc" bdev_get_bdevs >"/tmp/mooncake-target-bdevs-$RUN_ID.json"
  python3 - "/tmp/mooncake-target-bdevs-$RUN_ID.json" <<'PY'
import json, sys
for bdev in json.load(open(sys.argv[1])):
    for controller in bdev.get("driver_specific", {}).get("nvme", []):
        serial = controller.get("ctrlr_data", {}).get("serial_number", "").strip()
        if serial == "PHAL13400005400AGN": raise SystemExit(0)
raise SystemExit("target serial mismatch")
PY
  target_cmd sudo -n "$target_rpc" bdev_nvme_get_controller_health_info -c Nvme0 \
    >"/tmp/mooncake-target-health-$RUN_ID.json"
  python3 - "/tmp/mooncake-target-health-$RUN_ID.json" <<'PY'
import json, sys
data = json.load(open(sys.argv[1]))
if data.get("serial_number", "").strip() != "PHAL13400005400AGN": raise SystemExit("health serial mismatch")
if int(data.get("media_errors", 0)) or float(data.get("temperature_celsius", 0)) >= 70:
    raise SystemExit(f"unsafe target SMART: {data}")
PY
}

target_snapshot() {
  local when=$1 prefix=$2 case_id=$3 destination
  destination="$remote_out/telemetry/$prefix"
  ssh -o BatchMode=yes "$target" bash -s -- "$target_rpc" "$case_id.$when.spdk-iostat.json" "$case_id.$when.target-smart.json" <<'EOF' |
set -Eeuo pipefail
rpc=$1
spdk_name=$2
smart_name=$3
snapshot_dir=$(mktemp -d)
trap 'rm -rf "$snapshot_dir"' EXIT
sudo -n "$rpc" bdev_get_iostat >"$snapshot_dir/$spdk_name"
sudo -n "$rpc" bdev_nvme_get_controller_health_info -c Nvme0 >"$snapshot_dir/$smart_name"
tar -C "$snapshot_dir" -cf - "$spdk_name" "$smart_name"
EOF
    ssh -o BatchMode=yes "$client" tar --warning=no-timestamp -C "$destination" -xf -
}

case_snapshot() {
  local when=$1 prefix=$2 case_id=$3
  client_action snapshot-case WHEN="$when" PREFIX="$prefix" CASE_ID="$case_id"
  target_snapshot "$when" "$prefix" "$case_id"
}

run_case() {
  local kind=$1 name1=$2 name2=$3 mode=$4 target_name=$5 case_id=$6 prefix
  if [[ $kind == cell ]]; then prefix="$name1-trial$name2"; else prefix="anchor-$name1-$name2"; fi
  case_snapshot before "$prefix" "$case_id"
  client_action run-case KIND="$kind" NAME1="$name1" NAME2="$name2" MODE="$mode" TARGET="$target_name" CASE_ID="$case_id"
  case_snapshot after "$prefix" "$case_id"
}

run_pair() {
  local kind=$1 name1=$2 name2=$3 target_name=$4 order=$5 phase=$6 scenario=$7 trial=$8 first second
  if [[ $order == DT ]]; then first=direct; second=transparent; else first=transparent; second=direct; fi
  client_action check-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial" MARKER="before-$first-${target_name%%_*}"
  run_case "$kind" "$name1" "$name2" "$first" "$target_name" "$first-${target_name%%_*}"
  client_action check-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial" MARKER="between-${first}-${second}-${target_name%%_*}"
  run_case "$kind" "$name1" "$name2" "$second" "$target_name" "$second-${target_name%%_*}"
  client_action check-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial" MARKER="after-$second-${target_name%%_*}"
}

restore_round_robin() {
  set +e
  client_action start-master POLICY=round_robin LABEL=final-round-robin
  local master_rc=$?
  client_action register LABEL=final-round-robin
  local register_rc=$?
  client_action recovery-smoke
  local smoke_rc=$?
  set -e
  return $((master_rc || register_rc || smoke_rc))
}

on_exit() {
  local rc=$?
  trap - EXIT
  if [[ -n $active_scenario ]]; then
    client_action abort-load PHASE="$active_phase" SCENARIO="$active_scenario" TRIAL="$active_trial" || true
  fi
  if (( restore_needed )); then restore_round_robin || true; fi
  exit "$rc"
}
trap on_exit EXIT

scp -q "$helper" "$client:$remote_helper"
client_action preflight
target_preflight
scp -q "/tmp/mooncake-target-health-$RUN_ID.json" "$client:$remote_out/inventory/target-smart-before.json"

cat >"/tmp/mooncake-load-design-$RUN_ID.json" <<'JSON'
{
  "status_policy": "fail_closed_to_inconclusive",
  "workload": {"requests": 24, "blocks_per_request": 4, "block_size": 131072, "reuse_ratio": 0.5, "configured_concurrency": 1, "seed": 42},
  "scenarios": ["idle", "local50", "local90", "remote_stress"],
  "scenario_orders": {
    "1": ["idle", "local50", "local90", "remote_stress"],
    "2": ["local50", "remote_stress", "idle", "local90"],
    "3": ["local90", "idle", "remote_stress", "local50"],
    "4": ["remote_stress", "local90", "local50", "idle"]
  },
  "mode_orders": {"1": "direct_then_transparent", "2": "transparent_then_direct", "3": "direct_then_transparent", "4": "transparent_then_direct"},
  "claim_boundary": "Fixed 128 KiB, 50% configured reuse, sequential configured concurrency 1, single-client synthetic replay; no serving, TTFT, exact utilization, transport-only, adaptive-policy, generalized-crossover, isolation, or true-concurrency claim."
}
JSON
scp -q "/tmp/mooncake-load-design-$RUN_ID.json" "$client:$remote_out/design.json"
scp -q "/tmp/mooncake-target-service-$RUN_ID.txt" "$client:$remote_out/inventory/target-service-before.txt"

for scenario in idle local50 local90 remote_stress; do
  for trial in 1 2 3 4; do client_action generate-cell SCENARIO="$scenario" TRIAL="$trial"; done
done
for target_name in local_nvme remote_nof; do
  for position in pre post; do client_action generate-anchor TARGET="$target_name" POSITION="$position"; done
done

for phase in local remote; do
  if [[ $phase == local ]]; then policy=local_only; target_name=local_nvme; else policy=remote_only; target_name=remote_nof; fi
  client_action start-master POLICY="$policy" LABEL="$phase-phase"
  client_action register LABEL="$phase-phase"
  target_preflight
  client_action policy-smoke POLICY="$policy" TARGET="$target_name"

  client_action start-load PHASE="$phase" SCENARIO=idle TRIAL=anchor-pre
  active_phase=$phase active_scenario=idle active_trial=anchor-pre
  run_pair anchor "$target_name" pre "$target_name" DT "$phase" idle anchor-pre
  client_action finish-load PHASE="$phase" SCENARIO=idle TRIAL=anchor-pre
  active_phase= active_scenario= active_trial=

  for trial in 1 2 3 4; do
    case "$trial" in
      1) order=(idle local50 local90 remote_stress); mode_order=DT ;;
      2) order=(local50 remote_stress idle local90); mode_order=TD ;;
      3) order=(local90 idle remote_stress local50); mode_order=DT ;;
      4) order=(remote_stress local90 local50 idle); mode_order=TD ;;
    esac
    for scenario in "${order[@]}"; do
      client_action start-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial"
      active_phase=$phase active_scenario=$scenario active_trial=$trial
      if [[ $phase == local ]]; then
        client_action check-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial" MARKER=before-no_store
        run_case cell "$scenario" "$trial" no_store '' no_store
        client_action check-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial" MARKER=after-no_store
      fi
      run_pair cell "$scenario" "$trial" "$target_name" "$mode_order" "$phase" "$scenario" "$trial"
      client_action finish-load PHASE="$phase" SCENARIO="$scenario" TRIAL="$trial"
      active_phase= active_scenario= active_trial=
    done
  done

  client_action start-load PHASE="$phase" SCENARIO=idle TRIAL=anchor-post
  active_phase=$phase active_scenario=idle active_trial=anchor-post
  run_pair anchor "$target_name" post "$target_name" TD "$phase" idle anchor-post
  client_action finish-load PHASE="$phase" SCENARIO=idle TRIAL=anchor-post
  active_phase= active_scenario= active_trial=
  client_action check-master-log LABEL="$phase-phase"
done

for scenario in idle local50 local90 remote_stress; do
  for trial in 1 2 3 4; do client_action summarize-cell SCENARIO="$scenario" TRIAL="$trial"; done
done
for target_name in local_nvme remote_nof; do
  for position in pre post; do client_action summarize-anchor TARGET="$target_name" POSITION="$position"; done
done

restore_round_robin
restore_needed=0
target_preflight
scp -q "/tmp/mooncake-target-health-$RUN_ID.json" "$client:$remote_out/inventory/target-smart-after.json"
target_cmd sudo -n systemctl show mooncake-nof-spdk.service -p MainPID -p ActiveState -p SubState \
  >"/tmp/mooncake-target-service-$RUN_ID-after.txt"
scp -q "/tmp/mooncake-target-service-$RUN_ID-after.txt" "$client:$remote_out/inventory/target-service-after.txt"
client_action final-inventory
printf '%s\n' "$remote_out"
