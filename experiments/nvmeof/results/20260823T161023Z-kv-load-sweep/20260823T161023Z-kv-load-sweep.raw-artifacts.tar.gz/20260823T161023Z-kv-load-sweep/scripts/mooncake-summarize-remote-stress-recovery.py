#!/usr/bin/env python3
import json
import sys
from pathlib import Path


root = Path(sys.argv[1])
reference_iops = 6976.25
trials = []
failures = []
for trial in (2, 4):
    load = json.loads(
        (root / "loads" / f"remote-recovery-{trial}-remote_stress-trial{trial}.achieved.json").read_text()
    )
    conclusion = json.loads(
        (root / "cells" / f"remote_stress_recovery-trial{trial}" / "conclusion.json").read_text()
    )
    rows = conclusion.get("cases", [])
    if conclusion.get("status") != "pass" or len(rows) != 2:
        failures.append(f"trial {trial}: foreground conclusion mismatch")
    for row in rows:
        if row.get("operations") != 148 or row.get("miss") != 0 or row.get("remote") != 148 or row.get("local") != 0:
            failures.append(f"trial {trial}/{row.get('case_id')}: foreground invariant mismatch")
    if load.get("failed_ops") != 0 or load.get("completed_ops", 0) <= 0:
        failures.append(f"trial {trial}: load operation failure")
    ratio = float(load["iops"]) / reference_iops
    trials.append(
        {
            "trial": trial,
            "mode_order": "transparent_then_direct",
            "cooldown_sec": 15,
            "load_iops": load["iops"],
            "load_bw_reported": load["bw_GiBps"],
            "load_to_calibration_ratio": ratio,
            "load_classification": "healthy" if 0.8 <= ratio <= 1.2 else "collapsed",
            "completed_ops": load["completed_ops"],
            "failed_ops": load["failed_ops"],
            "foreground": {row["mode"]: {"request_p50_latency_us": row["request_p50_latency_us"], "request_p95_latency_us": row["request_p95_latency_us"]} for row in rows},
        }
    )

classifications = {trial["load_classification"] for trial in trials}
if classifications != {"healthy", "collapsed"}:
    failures.append(f"expected one healthy and one collapsed recovery epoch, got {classifications}")
result = {
    "status": "reproduced_instability" if not failures else "inconclusive",
    "reference_iops": reference_iops,
    "trials": trials,
    "interpretation": "The same transparent-first order and 15-second cooldown produced one healthy and one collapsed remote offered-load epoch; the stress point is nondeterministic and is excluded from overhead claims.",
    "failures": failures,
}
(root / "remote-stress-recovery-conclusion.json").write_text(
    json.dumps(result, indent=2, sort_keys=True) + "\n"
)
print(json.dumps(result, sort_keys=True))
raise SystemExit(0 if not failures else 1)
