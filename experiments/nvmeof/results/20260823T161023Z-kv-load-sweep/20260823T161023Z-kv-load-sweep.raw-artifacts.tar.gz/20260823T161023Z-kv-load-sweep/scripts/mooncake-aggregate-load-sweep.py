#!/usr/bin/env python3
import csv
import json
import re
import statistics
import sys
from pathlib import Path


root = Path(sys.argv[1])
scenarios = ("idle", "local50", "local90", "remote_stress")
targets = ("local_nvme", "remote_nof")
required_cases = {
    "no_store",
    "direct-local",
    "transparent-local",
    "direct-remote",
    "transparent-remote",
}
matrix_rows = []
operation_rows = []
telemetry_rows = []
anchor_rows = []
load_rows = []
failures = []
digests = set()
remote_reference_iops = 6976.25


def percentile(values, percent):
    ordered = sorted(values)
    return ordered[max(0, (percent * len(ordered) + 99) // 100 - 1)]


def read_csv(path):
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def validate_summary(row, context):
    operations = int(row["operations"])
    if operations != 148:
        failures.append(f"{context}: operations={operations}")
    if int(row["miss"]) != 0:
        failures.append(f"{context}: misses={row['miss']}")
    if row["target"] == "local_nvme":
        if int(row["local"]) != operations or int(row["remote"]) != 0:
            failures.append(f"{context}: local descriptor mismatch")
    elif row["target"] == "remote_nof":
        if int(row["remote"]) != operations or int(row["local"]) != 0:
            failures.append(f"{context}: remote descriptor mismatch")
    elif row["mode"] == "no_store":
        if int(row["local"]) != 0 or int(row["remote"]) != 0:
            failures.append(f"{context}: no-store descriptors")


def validate_smart(path, context, target=False):
    try:
        data = json.loads(path.read_text())
    except Exception as error:
        failures.append(f"{context}: invalid SMART JSON: {error}")
        return None
    temperature = float(data.get("temperature_celsius", data.get("temperature", 0)))
    if temperature > 200:
        temperature -= 273.15
    critical = int(data.get("critical_warning", 0))
    media = int(data.get("media_errors", 0))
    serial = data.get("serial_number", "").strip()
    if critical or media or temperature >= 70:
        failures.append(f"{context}: unsafe SMART critical={critical} media={media} temp={temperature}")
    if target and serial != "PHAL13400005400AGN":
        failures.append(f"{context}: target serial={serial!r}")
    return temperature


def collect_case_telemetry(prefix, case_id, scenario, trial, target, anchor_position=""):
    directory = root / "telemetry" / prefix
    system_path = directory / f"{case_id}.system.json"
    time_path = directory / f"{case_id}.time.txt"
    if not system_path.is_file() or not time_path.is_file():
        failures.append(f"{prefix}/{case_id}: missing system/time telemetry")
        return
    system = json.loads(system_path.read_text())
    if int(system.get("exit_code", -1)) != 0:
        failures.append(f"{prefix}/{case_id}: telemetry exit={system.get('exit_code')}")
    row = {
        "scenario": scenario,
        "trial": trial,
        "target": target,
        "anchor_position": anchor_position,
        "case_id": case_id,
        **system,
    }
    for when in ("before", "after"):
        required = (
            "utc.txt",
            "rdma.txt",
            "local-smart.json",
            "diskstats.txt",
            "netdev.txt",
            "master.json",
            "spdk-iostat.json",
            "target-smart.json",
        )
        for suffix in required:
            path = directory / f"{case_id}.{when}.{suffix}"
            if not path.is_file() or path.stat().st_size == 0:
                failures.append(f"{prefix}/{case_id}: missing {when}.{suffix}")
        local_temp = validate_smart(
            directory / f"{case_id}.{when}.local-smart.json",
            f"{prefix}/{case_id}/{when}/local",
        )
        target_temp = validate_smart(
            directory / f"{case_id}.{when}.target-smart.json",
            f"{prefix}/{case_id}/{when}/target",
            target=True,
        )
        row[f"local_temperature_c_{when}"] = local_temp
        row[f"target_temperature_c_{when}"] = target_temp
        try:
            master = json.loads((directory / f"{case_id}.{when}.master.json").read_text())
            expected_policy = "local_only" if target in ("local_nvme", "") else "remote_only"
            if anchor_position and target == "remote_nof":
                expected_policy = "remote_only"
            if master.get("owner") != "root" or master.get("policy") != expected_policy:
                failures.append(f"{prefix}/{case_id}/{when}: master={master}")
        except Exception as error:
            failures.append(f"{prefix}/{case_id}/{when}: invalid master telemetry: {error}")
    telemetry_rows.append(row)


for scenario in scenarios:
    for trial in range(1, 5):
        cell = root / "cells" / f"{scenario}-trial{trial}"
        try:
            manifest = json.loads((cell / "manifest.json").read_text())
            conclusion = json.loads((cell / "conclusion.json").read_text())
            rows = read_csv(cell / "summary.csv")
        except Exception as error:
            failures.append(f"{cell.name}: unreadable cell: {error}")
            continue
        digests.add(manifest["trace_sha256"])
        parameters = manifest["parameters"]
        expected_parameters = {
            "requests": 24,
            "blocks_per_request": 4,
            "block_size": 131072,
            "reuse_ratio": 0.5,
            "concurrency": 1,
            "policy": "round_robin",
        }
        for name, expected in expected_parameters.items():
            if parameters.get(name) != expected:
                failures.append(f"{cell.name}: {name}={parameters.get(name)!r}")
        if manifest.get("event_count") != 148:
            failures.append(f"{cell.name}: event_count={manifest.get('event_count')}")
        if conclusion.get("status") != "pass" or set(conclusion.get("completed_cases", [])) != required_cases:
            failures.append(f"{cell.name}: conclusion mismatch")
        if len(rows) != 5:
            failures.append(f"{cell.name}: summary rows={len(rows)}")
        for row in rows:
            validate_summary(row, f"{cell.name}/{row['case_id']}")
            matrix_rows.append(
                {"scenario": scenario, "trial": trial, "trace_sha256": manifest["trace_sha256"], **row}
            )
            collect_case_telemetry(
                f"{scenario}-trial{trial}", row["case_id"], scenario, trial, row["target"]
            )
        raw_operations = read_csv(cell / "operations.csv")
        groups = {}
        for row in raw_operations:
            key = (row["case_id"], row["mode"], row["target"], row["store_operation"])
            groups.setdefault(key, []).append(float(row["latency_us"]))
        for (case_id, mode, target, operation), values in sorted(groups.items()):
            operation_rows.append(
                {
                    "scenario": scenario,
                    "trial": trial,
                    "target": target,
                    "mode": mode,
                    "case_id": case_id,
                    "operation": operation,
                    "count": len(values),
                    "mean_us": round(statistics.fmean(values), 6),
                    "p50_us": round(percentile(values, 50), 6),
                    "p95_us": round(percentile(values, 95), 6),
                    "p99_us": round(percentile(values, 99), 6),
                }
            )

for target in targets:
    for position in ("pre", "post"):
        directory = root / "anchors" / f"{target}-{position}"
        try:
            conclusion = json.loads((directory / "conclusion.json").read_text())
            rows = read_csv(directory / "summary.csv")
        except Exception as error:
            failures.append(f"anchor {target}/{position}: {error}")
            continue
        expected = {f"direct-{target.split('_')[0]}", f"transparent-{target.split('_')[0]}"}
        if conclusion.get("status") != "pass" or set(conclusion.get("completed_cases", [])) != expected:
            failures.append(f"anchor {target}/{position}: conclusion mismatch")
        for row in rows:
            validate_summary(row, f"anchor-{target}-{position}/{row['case_id']}")
            anchor_rows.append({"target": target, "position": position, **row})
            collect_case_telemetry(
                f"anchor-{target}-{position}", row["case_id"], "idle_anchor", "", target, position
            )

for phase in ("local", "remote"):
    for scenario in scenarios:
        for trial in range(1, 5):
            prefix = root / "loads" / f"{phase}-{scenario}-trial{trial}"
            meta_path = Path(f"{prefix}.meta.json")
            if not meta_path.is_file():
                failures.append(f"load {phase}/{scenario}/{trial}: missing metadata")
                continue
            meta = json.loads(meta_path.read_text())
            row = {"phase": phase, "scenario": scenario, "trial": trial, **meta}
            if scenario != "idle":
                achieved_path = Path(f"{prefix}.achieved.json")
                termination_path = Path(f"{prefix}.termination.txt")
                status_path = Path(f"{prefix}.unit-status.txt")
                if not achieved_path.is_file() or not termination_path.is_file() or not status_path.is_file():
                    failures.append(f"load {phase}/{scenario}/{trial}: incomplete termination evidence")
                else:
                    row.update(json.loads(achieved_path.read_text()))
                    status = status_path.read_text()
                    if "Result=success" not in status or "ExecMainStatus=0" not in status:
                        failures.append(f"load {phase}/{scenario}/{trial}: unit failure")
                if scenario.startswith("local"):
                    ratio = float(row.get("achieved_to_requested_ratio", 0))
                    if not 0.85 <= ratio <= 1.10:
                        failures.append(f"load {phase}/{scenario}/{trial}: ratio={ratio}")
                elif int(row.get("failed_ops", -1)) != 0 or int(row.get("completed_ops", 0)) <= 0 or float(row.get("iops", 0)) <= 0:
                    failures.append(f"load {phase}/{scenario}/{trial}: NoF failures")
                elif not 0.80 <= float(row["iops"]) / remote_reference_iops <= 1.20:
                    failures.append(
                        f"load {phase}/{scenario}/{trial}: remote load drift "
                        f"iops={row['iops']} reference={remote_reference_iops}"
                    )
            load_rows.append(row)

if len(matrix_rows) != 80:
    failures.append(f"matrix rows={len(matrix_rows)}")
if len(telemetry_rows) != 88:
    failures.append(f"telemetry rows={len(telemetry_rows)}")
if len(anchor_rows) != 8:
    failures.append(f"anchor rows={len(anchor_rows)}")
if len(load_rows) != 32:
    failures.append(f"load rows={len(load_rows)}")
if len(digests) != 1:
    failures.append(f"trace digests={sorted(digests)}")

matrix_fields = ["scenario", "trial", "trace_sha256"] + list(matrix_rows[0].keys())[3:] if matrix_rows else []
with (root / "matrix-summary.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=matrix_fields)
    writer.writeheader(); writer.writerows(matrix_rows)

if operation_rows:
    with (root / "operation-summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(operation_rows[0]))
        writer.writeheader(); writer.writerows(operation_rows)

numeric_metrics = (
    "p50_latency_us", "p95_latency_us", "p99_latency_us",
    "request_p50_latency_us", "request_p95_latency_us", "storage_wait_us", "operation_rate",
)
paired_rows = []
for scenario in scenarios:
    for target in targets:
        for metric in numeric_metrics:
            direct_values, transparent_values = [], []
            for trial in range(1, 5):
                rows = [r for r in matrix_rows if r["scenario"] == scenario and int(r["trial"]) == trial and r["target"] == target]
                by_mode = {r["mode"]: float(r[metric]) for r in rows}
                if set(by_mode) != {"direct", "transparent"}:
                    failures.append(f"pair missing {scenario}/{target}/{trial}/{metric}")
                    continue
                direct_values.append(by_mode["direct"]); transparent_values.append(by_mode["transparent"])
            if len(direct_values) == 4:
                deltas = [(t / d - 1) * 100 for d, t in zip(direct_values, transparent_values)]
                direct_median = statistics.median(direct_values)
                transparent_median = statistics.median(transparent_values)
                paired_rows.append({
                    "scenario": scenario, "target": target, "metric": metric,
                    "direct_median": round(direct_median, 6),
                    "transparent_median": round(transparent_median, 6),
                    "ratio_of_medians_pct": round((transparent_median / direct_median - 1) * 100, 6),
                    "median_paired_delta_pct": round(statistics.median(deltas), 6),
                    "min_paired_delta_pct": round(min(deltas), 6),
                    "max_paired_delta_pct": round(max(deltas), 6),
                })
        for operation in ("put", "get", "remove"):
            for statistic in ("p50_us", "p95_us", "p99_us"):
                direct_values, transparent_values = [], []
                for trial in range(1, 5):
                    rows = [r for r in operation_rows if r["scenario"] == scenario and int(r["trial"]) == trial and r["target"] == target and r["operation"] == operation]
                    by_mode = {r["mode"]: float(r[statistic]) for r in rows}
                    if set(by_mode) != {"direct", "transparent"}:
                        direct_values = []; break
                    direct_values.append(by_mode["direct"]); transparent_values.append(by_mode["transparent"])
                if direct_values:
                    deltas = [(t / d - 1) * 100 for d, t in zip(direct_values, transparent_values)]
                    direct_median = statistics.median(direct_values)
                    transparent_median = statistics.median(transparent_values)
                    paired_rows.append({
                        "scenario": scenario, "target": target, "metric": f"{operation}_{statistic}",
                        "direct_median": round(direct_median, 6),
                        "transparent_median": round(transparent_median, 6),
                        "ratio_of_medians_pct": round((transparent_median / direct_median - 1) * 100, 6),
                        "median_paired_delta_pct": round(statistics.median(deltas), 6),
                        "min_paired_delta_pct": round(min(deltas), 6),
                        "max_paired_delta_pct": round(max(deltas), 6),
                    })

if paired_rows:
    with (root / "paired-overhead-summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(paired_rows[0]))
        writer.writeheader(); writer.writerows(paired_rows)

anchor_drift_rows = []
for target in targets:
    for mode in ("direct", "transparent"):
        for metric in ("p50_latency_us", "p95_latency_us", "request_p50_latency_us", "request_p95_latency_us"):
            values = {r["position"]: float(r[metric]) for r in anchor_rows if r["target"] == target and r["mode"] == mode}
            if set(values) == {"pre", "post"}:
                anchor_drift_rows.append({"target": target, "mode": mode, "metric": metric, "pre": values["pre"], "post": values["post"], "drift_pct": round((values["post"] / values["pre"] - 1) * 100, 6)})
if anchor_drift_rows:
    with (root / "anchor-drift-summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(anchor_drift_rows[0]))
        writer.writeheader(); writer.writerows(anchor_drift_rows)

for name, rows in (("telemetry-summary.csv", telemetry_rows), ("load-summary.csv", load_rows), ("anchor-summary.csv", anchor_rows)):
    if rows:
        fields = []
        for row in rows:
            for key in row:
                if key not in fields: fields.append(key)
        with (root / name).open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader(); writer.writerows(rows)

for label in ("local-phase", "remote-phase", "final-round-robin"):
    log = root / "service-logs" / f"master-{label}.log"
    if not log.is_file() or re.search(r"nof_heartbeat_failure|unmount_nof_segment_by_heartbeat", log.read_text(errors="replace")):
        failures.append(f"master {label}: missing or heartbeat/unmount failure")

recovery = root / "smoke" / "final-round-robin" / "transparent-round-robin.json"
try:
    report = json.loads(recovery.read_text())
    if report.get("status") != "pass" or report.get("objects_verified") != 12 or report.get("objects_removed") != 12 or report.get("phantom_replicas") != 0 or report.get("target_counts") != {"local_nvme": 6, "remote_nof": 6}:
        failures.append(f"recovery smoke mismatch: {report}")
except Exception as error:
    failures.append(f"recovery smoke unreadable: {error}")

conclusion = {
    "status": "pass" if not failures else "inconclusive",
    "cell_count": 16,
    "case_rows": len(matrix_rows),
    "expected_case_rows": 80,
    "anchor_case_rows": len(anchor_rows),
    "telemetry_case_rows": len(telemetry_rows),
    "load_epochs": len(load_rows),
    "trace_digests": sorted(digests),
    "scenario_status": {
        scenario: (
            "inconclusive"
            if any(f"/{scenario}/" in failure for failure in failures)
            else "pass"
        )
        for scenario in scenarios
    },
    "failures": failures,
}
(root / "matrix-conclusion.json").write_text(json.dumps(conclusion, indent=2, sort_keys=True) + "\n")
print(json.dumps(conclusion, sort_keys=True))
raise SystemExit(0 if not failures else 1)
