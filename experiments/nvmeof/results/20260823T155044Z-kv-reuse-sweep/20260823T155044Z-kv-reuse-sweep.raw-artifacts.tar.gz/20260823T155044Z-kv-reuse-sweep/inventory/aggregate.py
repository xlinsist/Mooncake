#!/usr/bin/env python3
import csv
import json
import statistics
import sys
from pathlib import Path


root = Path(sys.argv[1])
required_cases = {
    "no_store",
    "direct-local",
    "transparent-local",
    "direct-remote",
    "transparent-remote",
}
ratio_by_label = {"0": 0.0, "50": 0.5, "90": 0.9}
expected_events = {0.0: 192, 0.5: 148, 0.9: 104}
matrix_rows = []
operation_rows = []
failures = []
digests = {ratio: set() for ratio in expected_events}

for cell in sorted((root / "cells").iterdir()):
    if not cell.is_dir():
        continue
    prefix, trial_text = cell.name.split("-trial", 1)
    ratio = ratio_by_label[prefix.removeprefix("reuse")]
    trial = int(trial_text)
    manifest = json.loads((cell / "manifest.json").read_text())
    conclusion = json.loads((cell / "conclusion.json").read_text())
    digests[ratio].add(manifest["trace_sha256"])
    if manifest["parameters"]["reuse_ratio"] != ratio:
        failures.append(f"{cell.name}: manifest reuse ratio mismatch")
    if manifest["event_count"] != expected_events[ratio]:
        failures.append(f"{cell.name}: event count mismatch")
    if conclusion["status"] != "pass":
        failures.append(f"{cell.name}: conclusion {conclusion['status']}")
    if set(conclusion["completed_cases"]) != required_cases:
        failures.append(f"{cell.name}: completed cases mismatch")
    with (cell / "summary.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    if len(rows) != 5:
        failures.append(f"{cell.name}: expected 5 summary rows, got {len(rows)}")
    for row in rows:
        enriched = {
            "reuse_ratio": ratio,
            "trial": trial,
            "trace_sha256": manifest["trace_sha256"],
            **row,
        }
        matrix_rows.append(enriched)
        operations = int(row["operations"])
        if operations != expected_events[ratio]:
            failures.append(f"{cell.name}/{row['case_id']}: operations={operations}")
        if int(row["miss"]) != 0:
            failures.append(f"{cell.name}/{row['case_id']}: misses")
        if row["target"] == "local_nvme":
            if int(row["local"]) != operations or int(row["remote"]) != 0:
                failures.append(f"{cell.name}/{row['case_id']}: local descriptors")
        elif row["target"] == "remote_nof":
            if int(row["remote"]) != operations or int(row["local"]) != 0:
                failures.append(f"{cell.name}/{row['case_id']}: remote descriptors")
        elif row["mode"] == "no_store":
            if int(row["local"]) != 0 or int(row["remote"]) != 0:
                failures.append(f"{cell.name}/{row['case_id']}: no-store descriptors")
    with (cell / "operations.csv").open(newline="") as stream:
        raw_operations = list(csv.DictReader(stream))
    groups = {}
    for row in raw_operations:
        key = (row["case_id"], row["mode"], row["target"], row["store_operation"])
        groups.setdefault(key, []).append(float(row["latency_us"]))
    for (case_id, mode, target, operation), values in sorted(groups.items()):
        ordered = sorted(values)
        percentile = lambda p: ordered[max(0, (p * len(ordered) + 99) // 100 - 1)]
        operation_rows.append(
            {
                "reuse_ratio": ratio,
                "trial": trial,
                "target": target,
                "mode": mode,
                "case_id": case_id,
                "operation": operation,
                "count": len(values),
                "mean_us": round(statistics.fmean(values), 6),
                "p50_us": round(percentile(50), 6),
                "p95_us": round(percentile(95), 6),
                "p99_us": round(percentile(99), 6),
            }
        )

if len(matrix_rows) != 45:
    failures.append(f"matrix rows={len(matrix_rows)}")
if any(len(values) != 1 for values in digests.values()):
    failures.append(f"unstable trace digests: {digests}")

matrix_fields = [
    "reuse_ratio",
    "trial",
    "trace_sha256",
    "case_id",
    "mode",
    "target",
    "operations",
    "produce",
    "reuse",
    "evict",
    "local",
    "remote",
    "miss",
    "miss_rate",
    "block_hit_rate",
    "request_count",
    "request_hit_rate",
    "p50_latency_us",
    "p95_latency_us",
    "p99_latency_us",
    "request_p50_latency_us",
    "request_p95_latency_us",
    "storage_wait_us",
    "operation_rate",
    "cpu_utilization_pct",
]
with (root / "matrix-summary.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=matrix_fields)
    writer.writeheader()
    writer.writerows(matrix_rows)

operation_fields = [
    "reuse_ratio",
    "trial",
    "target",
    "mode",
    "case_id",
    "operation",
    "count",
    "mean_us",
    "p50_us",
    "p95_us",
    "p99_us",
]
with (root / "operation-summary.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=operation_fields)
    writer.writeheader()
    writer.writerows(operation_rows)

numeric_metrics = [
    "p50_latency_us",
    "p95_latency_us",
    "p99_latency_us",
    "request_p50_latency_us",
    "request_p95_latency_us",
    "storage_wait_us",
    "operation_rate",
]
paired_rows = []


def append_paired_row(ratio, target, metric, direct_values, transparent_values):
    deltas = [
        (transparent / direct - 1) * 100
        for direct, transparent in zip(direct_values, transparent_values)
    ]
    direct_median = statistics.median(direct_values)
    transparent_median = statistics.median(transparent_values)
    paired_rows.append(
        {
            "reuse_ratio": ratio,
            "target": target,
            "metric": metric,
            "direct_median": round(direct_median, 6),
            "transparent_median": round(transparent_median, 6),
            "ratio_of_medians_pct": round(
                (transparent_median / direct_median - 1) * 100, 6
            ),
            "median_paired_delta_pct": round(statistics.median(deltas), 6),
            "min_paired_delta_pct": round(min(deltas), 6),
            "max_paired_delta_pct": round(max(deltas), 6),
        }
    )


for ratio in sorted(expected_events):
    for target in ("local_nvme", "remote_nof"):
        for metric in numeric_metrics:
            direct_values = []
            transparent_values = []
            for trial in (1, 2, 3):
                rows = [
                    row
                    for row in matrix_rows
                    if float(row["reuse_ratio"]) == ratio
                    and int(row["trial"]) == trial
                    and row["target"] == target
                ]
                by_mode = {row["mode"]: float(row[metric]) for row in rows}
                direct = by_mode["direct"]
                transparent = by_mode["transparent"]
                direct_values.append(direct)
                transparent_values.append(transparent)
            append_paired_row(
                ratio, target, metric, direct_values, transparent_values
            )
        for operation in ("put", "get", "remove"):
            for statistic in ("p50_us", "p95_us", "p99_us"):
                direct_values = []
                transparent_values = []
                for trial in (1, 2, 3):
                    rows = [
                        row
                        for row in operation_rows
                        if float(row["reuse_ratio"]) == ratio
                        and int(row["trial"]) == trial
                        and row["target"] == target
                        and row["operation"] == operation
                    ]
                    by_mode = {row["mode"]: float(row[statistic]) for row in rows}
                    if set(by_mode) != {"direct", "transparent"}:
                        direct_values = []
                        transparent_values = []
                        break
                    direct_values.append(by_mode["direct"])
                    transparent_values.append(by_mode["transparent"])
                if direct_values:
                    append_paired_row(
                        ratio,
                        target,
                        f"{operation}_{statistic}",
                        direct_values,
                        transparent_values,
                    )

paired_fields = list(paired_rows[0])
with (root / "paired-overhead-summary.csv").open("w", newline="") as stream:
    writer = csv.DictWriter(stream, fieldnames=paired_fields)
    writer.writeheader()
    writer.writerows(paired_rows)

conclusion = {
    "status": "pass" if not failures else "inconclusive",
    "cell_count": 9,
    "case_rows": len(matrix_rows),
    "expected_case_rows": 45,
    "expected_events_by_reuse": {str(key): value for key, value in expected_events.items()},
    "trace_digests_by_reuse": {
        str(key): sorted(value) for key, value in digests.items()
    },
    "failures": failures,
}
(root / "matrix-conclusion.json").write_text(
    json.dumps(conclusion, indent=2, sort_keys=True) + "\n"
)
print(json.dumps(conclusion, sort_keys=True))
raise SystemExit(0 if not failures else 1)
