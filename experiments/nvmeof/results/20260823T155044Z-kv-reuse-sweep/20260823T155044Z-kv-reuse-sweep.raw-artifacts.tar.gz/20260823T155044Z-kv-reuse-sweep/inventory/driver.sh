#!/usr/bin/env bash
set -Eeuo pipefail

: "${RUN_ID:?set RUN_ID}"

repo=/sharenvme/userhome/zhouxulin/mooncake-kv-e82f0bb7
run_sh="$repo/experiments/nvmeof/run.sh"
master="$repo/build-nof/mooncake-store/src/mooncake_master"
out="/sharenvme/userhome/zhouxulin/mooncake-kv-reuse-results/$RUN_ID-kv-reuse-sweep"
required_cases=no_store,direct-local,transparent-local,direct-remote,transparent-remote
restore_needed=1

mkdir -p "$out" "$out/cells" "$out/service-logs" "$out/inventory" "$out/register"
exec > >(tee -a "$out/driver.log") 2>&1

wait_for_port() {
  local port=$1
  local expected=$2
  local attempt
  for attempt in $(seq 1 60); do
    if ss -ltn | grep -q ":$port "; then
      [[ $expected == up ]] && return 0
    else
      [[ $expected == down ]] && return 0
    fi
    sleep 0.5
  done
  echo "port $port did not become $expected" >&2
  return 1
}

stop_master() {
  local pids
  pids=$(pgrep -x mooncake_master || true)
  if [[ -n $pids ]]; then
    while read -r pid; do
      [[ -z $pid ]] || sudo -n kill "$pid"
    done <<<"$pids"
  fi
  wait_for_port 50051 down
  wait_for_port 9003 down
}

start_master() {
  local policy=$1
  local label=$2
  local log="$out/service-logs/master-$label.log"
  stop_master
  nohup sudo -n env MC_HETERO_STORAGE_POLICY="$policy" \
    "$master" --rpc_address=10.0.0.34 --enable_offload=true --logtostderr=true \
    >"$log" 2>&1 </dev/null &
  echo "$!" >"$out/service-logs/master-$label.launcher-pid"
  wait_for_port 50051 up
  wait_for_port 9003 up
  local pid owner actual_policy
  pid=$(pgrep -n -x mooncake_master)
  owner=$(ps -o user= -p "$pid" | xargs)
  actual_policy=$(sudo -n sh -c "tr '\\0' '\\n' </proc/$pid/environ" | sed -n 's/^MC_HETERO_STORAGE_POLICY=//p')
  [[ $owner == root ]]
  [[ $actual_policy == "$policy" ]]
  printf '%s %s %s %s\n' "$(date -u +%FT%TZ)" "$pid" "$owner" "$actual_policy" \
    >>"$out/inventory/master-transitions.txt"
}

register_nof() {
  local label=$1
  local register_dir="$out/register/$label"
  mkdir -p "$register_dir"
  RESULT_DIR="$register_dir" "$run_sh" register \
    >"$out/service-logs/register-$label.log" 2>&1
}

restore_round_robin() {
  set +e
  start_master round_robin final-round-robin
  local master_rc=$?
  register_nof final-round-robin
  local register_rc=$?
  ps -eo user,pid,ppid,args | grep '[m]ooncake_master' \
    >"$out/inventory/final-master.txt"
  ss -ltn | grep -E ':(50051|9003) ' >>"$out/inventory/final-master.txt"
  if grep -E 'nof_heartbeat_failure|unmount_nof_segment_by_heartbeat' \
      "$out/service-logs/master-final-round-robin.log"; then
    echo heartbeat_log=failed >>"$out/inventory/final-master.txt"
    master_rc=1
  else
    echo heartbeat_log=clean >>"$out/inventory/final-master.txt"
  fi
  set -e
  return $((master_rc || register_rc))
}

on_exit() {
  local rc=$?
  trap - EXIT
  if (( restore_needed )); then
    restore_round_robin || true
  fi
  exit "$rc"
}
trap on_exit EXIT

ratio_value() {
  case "$1" in
    r0) printf '0.0\n' ;;
    r50) printf '0.5\n' ;;
    r90) printf '0.9\n' ;;
    *) return 2 ;;
  esac
}

cell_dir() {
  printf '%s/cells/reuse%s-trial%s\n' "$out" "${1#r}" "$2"
}

generate_cell() {
  local ratio_label=$1
  local trial=$2
  local ratio
  local cell
  ratio=$(ratio_value "$ratio_label")
  cell=$(cell_dir "$ratio_label" "$trial")
  mkdir -p "$cell"
  RESULT_DIR="$out/harness" \
  KV_WORKLOAD_RUN_ID="$RUN_ID-$ratio_label-trial$trial" \
  KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUESTS=24 \
  KV_WORKLOAD_BLOCKS_PER_REQUEST=4 \
  KV_WORKLOAD_BLOCK_SIZE=131072 \
  KV_WORKLOAD_REUSE_RATIO="$ratio" \
  KV_WORKLOAD_CONCURRENCY=1 \
  KV_WORKLOAD_POLICY=round_robin \
  KV_WORKLOAD_SEED=42 \
    "$run_sh" kv-workload-generate >"$cell/generate.log" 2>&1
}

run_case() {
  local ratio_label=$1
  local trial=$2
  local mode=$3
  local target=$4
  local case_id=$5
  local cell
  cell=$(cell_dir "$ratio_label" "$trial")
  RESULT_DIR="$out/harness" \
  TRANSPARENT_RUN_ID="$RUN_ID" \
  KV_WORKLOAD_RUN_ID="$RUN_ID-$ratio_label-trial$trial" \
  KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_MODE="$mode" \
  KV_WORKLOAD_TARGET="$target" \
  KV_WORKLOAD_CASE_ID="$case_id" \
    "$run_sh" kv-workload-replay >"$cell/$case_id.log" 2>&1
}

run_pair() {
  local ratio_label=$1
  local trial=$2
  local target=$3
  local first=direct
  local second=transparent
  if [[ $trial == 2 ]]; then
    first=transparent
    second=direct
  fi
  run_case "$ratio_label" "$trial" "$first" "$target" "$first-${target%%_*}"
  run_case "$ratio_label" "$trial" "$second" "$target" "$second-${target%%_*}"
}

summarize_cell() {
  local ratio_label=$1
  local trial=$2
  local cell
  cell=$(cell_dir "$ratio_label" "$trial")
  RESULT_DIR="$out/harness" \
  KV_WORKLOAD_RESULT_DIR="$cell" \
  KV_WORKLOAD_REQUIRED_CASES="$required_cases" \
    "$run_sh" kv-workload-summarize >"$cell/summarize.log" 2>&1
}

date -u +%FT%TZ >"$out/inventory/started-utc.txt"
hostname >"$out/inventory/hostname.txt"
git -C "$repo" rev-parse HEAD >"$out/inventory/source-commit.txt"
git -C "$repo" status --short >"$out/inventory/source-status.txt"
sha256sum "$master" "$repo"/build-nof/mooncake-integration/mooncake/store*.so \
  >"$out/inventory/build-sha256.txt"
ps -eo user,pid,ppid,args | grep '[m]ooncake_master' >"$out/inventory/initial-master.txt"
ss -ltn | grep -E ':(50051|9003|8080) ' >>"$out/inventory/initial-master.txt"
nvme list-subsys >"$out/inventory/client-nvme-subsystems.txt"

for ratio_label in r0 r50 r90; do
  for trial in 1 2 3; do
    echo "generate $ratio_label trial $trial"
    generate_cell "$ratio_label" "$trial"
    run_case "$ratio_label" "$trial" no_store '' no_store
  done
done

start_master local_only local-phase
register_nof local-phase
for trial in 1 2 3; do
  case "$trial" in
    1) ratio_order=(r0 r50 r90) ;;
    2) ratio_order=(r90 r50 r0) ;;
    3) ratio_order=(r50 r0 r90) ;;
  esac
  for ratio_label in "${ratio_order[@]}"; do
    echo "local $ratio_label trial $trial"
    run_pair "$ratio_label" "$trial" local_nvme
  done
done
if grep -E 'nof_heartbeat_failure|unmount_nof_segment_by_heartbeat' \
    "$out/service-logs/master-local-phase.log"; then
  echo "local-phase Master heartbeat failure" >&2
  exit 1
fi

start_master remote_only remote-phase
register_nof remote-phase
for trial in 1 2 3; do
  case "$trial" in
    1) ratio_order=(r0 r50 r90) ;;
    2) ratio_order=(r90 r50 r0) ;;
    3) ratio_order=(r50 r0 r90) ;;
  esac
  for ratio_label in "${ratio_order[@]}"; do
    echo "remote $ratio_label trial $trial"
    register_nof "before-${ratio_label}-trial${trial}"
    run_pair "$ratio_label" "$trial" remote_nof
  done
done
if grep -E 'nof_heartbeat_failure|unmount_nof_segment_by_heartbeat' \
    "$out/service-logs/master-remote-phase.log"; then
  echo "remote-phase Master heartbeat failure" >&2
  exit 1
fi

for ratio_label in r0 r50 r90; do
  for trial in 1 2 3; do
    echo "summarize $ratio_label trial $trial"
    summarize_cell "$ratio_label" "$trial"
  done
done

restore_round_robin
restore_needed=0
date -u +%FT%TZ >"$out/inventory/completed-utc.txt"
printf '%s\n' "$out"
